export { default } from './NotFoundCover';
