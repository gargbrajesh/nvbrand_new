import React from 'react'
import styles from './NotFoundCover.module.css';
import LetsTalkBg from '../../../public/assets/Images/Img404.svg';


function UpcomingFeature() {
    return (
        <div style={{ backgroundImage: `url(${LetsTalkBg})`, backgroundRepeat: 'no-repeat' }} className={styles.container}>
            <div className="row mx-5">
                <div>

                    <div className={styles.inner_form_page}>
                       
                        <div className={styles.contentBox}>
                        
                       <p className={styles.typo1}>404</p>
                       <p className={styles.typo2}>Seems like strings aren’t connected</p>
                      <button className={styles.btn}> Back to home</button>
                        
                        </div>
                       
                    </div>

                </div>

            </div>
        </div>
    )
}

export default UpcomingFeature