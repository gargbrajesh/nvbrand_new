// import fileDefault from '../../../../../public/assets/Images/logo/file-blank-solid-240.png';
import fileCSS from '../../../../../public/assets/Images/logo/file-css-solid-240.png';
import filePdf from '../../../../../public/assets/Images/logo/file-pdf-solid-240.png';
import filePng from '../../../../../public/assets/Images/logo/file-png-solid-240.png';

export const ImageConfig = {
   
    pdf: filePdf,
    png: filePng,
    css: fileCSS
}