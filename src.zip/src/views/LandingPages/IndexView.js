import React from 'react';
import { makeStyles } from '@material-ui/core';
import { Banner } from './components';
import MetaTitle from 'components/helper/MetaTitle';

const useStyles = makeStyles(theme => ({
  root: {
    height: '91vh !important',
  },
}));

const IndexView = ({ themeMode }) => {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <MetaTitle
        title={`Home || Beatnik - For those who love art, live art `}
        metaKeyWord="Beatnik - For those who love art, live art "
        metaDescription="Beatnik - For those who love art, live art "
      />
   
         <Banner />
    
     
    </div>
  );
};

export default IndexView;
