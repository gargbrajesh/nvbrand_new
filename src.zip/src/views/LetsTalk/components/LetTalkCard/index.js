export { default } from './LetTalkCard';
