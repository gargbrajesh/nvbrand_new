import React, { useEffect, useState} from "react";
import { makeStyles, Container, Grid, Card } from "@material-ui/core";
import styles from "../Banner/Banner.module.css";
import Queryform from "../QueryForm/QueryForm";
import Email from "../../../../../public/assets/Images/common/Email.svg";
import Telephone from "../../../../../public/assets/Images/common/call.svg";
import Spinner from "components/organisms/Spinner";


const useStyles = makeStyles((theme) => ({
  root: {
    position: "relative",
    width: "100%",
  },
  card_container: {

    width: "100%",
    marginTop: '110px',
  },
  inner_containner: {
    background: "rgba(255, 255, 255, 0.8)",
    padding: '40px 60px 80px 60px',
  },
  textcontainer: {
    display: "block",
    width: "50%",

  },
  queryContainer: {
    top: ' 16%',
    left: '61%',
    width: '500px',
    /* height: 80vh, */
    padding: '35px 50px',
    position: 'absolute',
    background: 'white',
    display: 'block',
  },

}));
const LetTalkCard = () => {
  const classes = useStyles();
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    setLoading(true);
  }, []);
  return (
    <div className={classes.root}>
      {loading ? (<>
        <Container>
          <Grid xs={12}>
            <div className={classes.card_container}>
              <Card className={classes.inner_containner}>
                <Grid container className={classes.textcontainer}>
                  <h1 className={styles.heading}>Let's Talk</h1>
                  <p className={styles.para}>
                    Hello! Thanks for visiting Beatnik :).
                  </p>
                  <div className={styles.para}>
                    {" "}
                    We are excited to be on this journey to explore the art world
                    and build a sustainable community with art enthusiasts like
                    you!
                  </div>
                  <div className={styles.para}>
                    Please write to us or call us for any queries, suggestions or comments".
                    We would love to hear from you"

                  </div>
                  <div className={styles.para}>
                    <ul className={styles.contact} style={{ listStyle: "none" }}>
                      <li>
                        <a href="#" className={styles.anchor}>
                          <div>
                            <img src={Email} alt="" />
                            <span className="email-add">
                              {" "}
                              &nbsp;&nbsp;hello@beatnik.community
                            </span>
                          </div>{" "}
                        </a>
                      </li>
                      <li>
                        <a href="#" className={styles.anchor}>
                          <div>
                            <img src={Telephone} alt="" />
                            <span className="phone-number">
                              {" "}
                              &nbsp;&nbsp;+91 8197009093
                            </span>
                          </div>{" "}
                        </a>
                      </li>
                    </ul>
                  </div>
                </Grid>
              </Card>
              <Grid container className={classes.queryContainer}>
                <Queryform />
              </Grid>
            </div>
          </Grid>
        </Container>
      </>) : (<>
        <Spinner />
      </>)}

    </div>
  );
};

export default LetTalkCard;
