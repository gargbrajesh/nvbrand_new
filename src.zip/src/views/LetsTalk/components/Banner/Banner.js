import React from "react";
import LetsTalkBg from "../../../../../public/assets/Images/Upcomingfeatures.svg";
import { makeStyles } from "@material-ui/core";
import LetTalkCard from "../LetTalkCard";


const useStyles = makeStyles((theme) => ({
  banner_container: {
    position: "relative",
    width: "100%",
    height: "115vh",
  },
}));
const Banner = () => {
  const classes = useStyles();
  return (
    <div className={classes.banner_container}>
      <div
        style={{
          backgroundImage: `url(${LetsTalkBg})`,
          backgroundRepeat: "no-repeat",
          width: "100%",
          position: "absolute",
          height: "115vh",
          top: "-80px",
          left: "0",
          right: "0",
          backgroundSize: "100%",
        }}
      >
        <LetTalkCard />
      </div>
    </div>
  );
};

export default Banner;
