import React, { useState } from "react";
// import styles from "../../SignUpCover.module.css";
import { useRouter } from "next/router";
import styles from "../Banner/Banner.module.css";
import Router from "next/router";
import {
  Button,
  TextField,
  makeStyles,
  Container,
  Grid,
  Typography,
} from "@material-ui/core";
import { Formik, Field, Form } from "formik";
import * as Yup from "yup";
import Encodr from "encodr";
import Spinner from "components/organisms/Spinner";
import Snackbar from "@material-ui/core/Snackbar";
import MuiAlert from "@material-ui/lab/Alert";
import Cookies from "js-cookie";

function Alert(props) {
  return <MuiAlert elevation={6} variant="filled" {...props} />;
}
const useStyles = makeStyles((theme) => ({
  form_control_lg: {
    width: "100%",
    "& .MuiInputLabel-filled.MuiInputLabel-shrink.MuiInputLabel-marginDense": {
      transform: "translate(36px, -8px) scale(0.75)",
      background: "#fff",
      padding: "0 10px",
      color: "#FAA61A",
    },
    "& .MuiFilledInput-root": {
      backgroundColor: " #fff",
      borderRadius: "30px",
      border: " 2px solid #888888",
      borderBottom: " 2px solid #888888 !important",
      "&:active": {
        border: " 2px solid #FAA61A !important",
        borderBottom: " 2px solid #FAA61A !important",
      },
      "&:focus": {
        border: " 2px solid #FAA61A !important",
        borderBottom: " 2px solid #FAA61A !important",
      },
      "&:focus-within": {
        border: " 2px solid #FAA61A !important",
        borderBottom: " 2px solid #FAA61A !important",
      },
      "&:visited": {
        border: " 2px solid #FAA61A !important",
        borderBottom: " 2px solid #FAA61A !important",
      },
      "&:focus-visible": {
        border: " 2px solid #FAA61A !important",
        borderBottom: " 2px solid #FAA61A !important",
      },
      "&:target": {
        border: " 2px solid #FAA61A !important",
        borderBottom: " 2px solid #FAA61A !important",
      },
    },
    "& .MuiFilledInput-underline": {
      "&:before": {
        transition: "none",
        borderBottom: "none",
      },
      "&:after": {
        transition: "none",
        borderBottom: "none",
      },
      transition: "none",
      borderBottom: "none",
    },
    "& .MuiFilledInput-input": {
      padding: "10px 20px 8px 25px !important",
    },
    "& .MuiInputLabel-filled": {
      transform: "translate(20px, 12px) scale(1)",
    },
  },
  createAcc: {
    backgroundColor: " #faa61a",
    borderRadius: "30px",
    border: " 2px solid #faa61a",
    borderBottom: " 2px solid #faa61a !important",
    padding: "6px 60px",
    marginTop: "30px",
    "&:hover": {
      backgroundColor: " #faa61a !important" ,
    },
  },
  mobileNumber: {
    display: "flex",
    backgroundColor: " #fff",
    borderRadius: "30px",
    border: " 2px solid #888888",
    width: "100%",
  },
  formContainer: {
    position: "relative",
  },
  innerContianer: {
    marginTop: "20px",
    "& .MuiButton-containedPrimary ": {
      borderRadius: "20px",
      width: "100px",
    },
  },
}));
function Queryform() {
  const classes = useStyles();
  const router = useRouter();
  const [phoneNumber, setPhoneNumber] = useState();
  const [query, setQuery] = useState("");
  const [getMessage, setMessage] = useState("");
  const [getMessageTrue, setMessageTrue] = useState("");
  const [openFalse, setOpenFalse] = useState(false);
  const [openTrue, setOpenTrue] = useState(false);

  
  const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/

  const createAccountSubmit = async (values) => {
    var myHeaders = new Headers();
    // setOpenTrue(true);
    myHeaders.append(
      "Cookie",
      "ci_session=93ebf988fabcaf6b4bf9f45a6251d6aaf6e8c705"
    );
    var formdata = new FormData();
    formdata.append("fullName", values.name);
    formdata.append("email", values.email);
    formdata.append("number", values.phone);
    formdata.append("msg", values.query);
    var requestOptions = {
      method: "POST",
      headers: myHeaders,
      body: formdata,
      redirect: "follow",
    };
    const result = await fetch(
      process.env.NEXT_PUBLIC_USER_API_URL + `/beatnik_contact_form`,
      requestOptions
    )
      .then((response) => response.json())
      .then((responseJson) => {
        // setOpenFalse();
        //Hide Loader
        console.log(responseJson.valid);
        if (responseJson.valid == false) {
          setMessage(responseJson.result.message);

          setOpenFalse(true);
        } else {

          setMessageTrue(responseJson.result.message);
          setOpenTrue(true)

          setTimeout(() => {
            window.location.reload(true)
          }, 2000);

        }
      })
      .catch((error) => console.log("error", error));
  };
  const handleCloseFalse = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpenFalse(false);
  };
  const handleCloseTrue = (event, reason) => {
    if (reason === "clickaway") {
      return;
    }
    setOpenTrue(false);
  };
  return (
    <div>
      <Snackbar
        open={openFalse}
        autoHideDuration={1000}
        onClose={handleCloseFalse}
      >
        <Alert onClose={handleCloseFalse} severity="error">
          {getMessage}
        </Alert>
      </Snackbar>
      <Snackbar
        open={openTrue}
        autoHideDuration={1000}
        onClose={handleCloseTrue}
      >
        <Alert onClose={handleCloseTrue} severity="success">
          {getMessageTrue}
        </Alert>
      </Snackbar>
      <div>
        <Formik
          initialValues={{
            name: "",
            email: "",
            query: "",
            phone: "",
          }}
          validationSchema={Yup.object().shape({
            name: Yup.string()
              .max(30, "Name should be at greater then  30 characters.")
              .min(3, "Name must be at least 3 characters.")
              .required("Name is required"),
            email: Yup.string()
              .max(50)
              .required("Email ID is required.")
              .email("Email ID is invalid."),
            phone: Yup.string()
              .required("required")
              .matches(phoneRegExp, 'Phone number is not valid')
              .min(10, "to short")
              .max(10, "to long"),
              query: Yup.string()
              .max(250, "Message should not be at greater than 250 characters.")
              .min(50, "Message must be at least of 50 characters.")
              .required("Message is required"),
          })}
          onSubmit={async (values, { setSubmitting }) => {
            const result = createAccountSubmit(values, null, 2);
          }}
        >
          {({
            errors,
            handleBlur,
            handleChange,
            handleSubmit,
            isSubmitting,
            setFieldValue,
            isValid,
            touched,
            values,
          }) => (
            <div className={classes.formContainer}>
              <Grid item xs={12}>
                {" "}
                <Typography className={styles.sub_heading}>
                  Queries . Suggestions . Comments
                </Typography>

              </Grid>
              <Grid item className={classes.innerContianer}>
                <form onSubmit={handleSubmit} id="my-form" autoComplete="off">
                  <div className="form-outline mb-4">
                    <TextField
                      id="name"
                      variant="filled"
                      label="Name"
                      className={classes.form_control_lg}
                      error={Boolean(touched.name && errors.name)}
                      helperText={touched.name && errors.name}
                      name="name"
                      size="small"
                      onBlur={handleBlur}
                      onChange={handleChange}
                      value={values.name}
                    />
                  </div>
                  <div className="form-outline mb-4">
                    <TextField
                      id="email"
                      type="email"
                      variant="filled"
                      label="Email Address"
                      className={classes.form_control_lg}
                      error={Boolean(touched.email && errors.email)}
                      helperText={touched.email && errors.email}
                      name="email"
                      size="small"
                      onBlur={handleBlur}
                      onChange={handleChange}
                      value={values.email}
                    />
                  </div>

                  <div className="form-outline mb-4">
                    <TextField
                      id="phone"
                      type="phone"
                      variant="filled"
                      label="Phone Number"
                      className={classes.form_control_lg}
                      error={Boolean(touched.phone && errors.phone)}
                      helperText={touched.phone && errors.phone}
                      name="phone"
                      size="small"
                      onBlur={handleBlur}
                      onChange={handleChange}
                      value={values.phone}
                    />
                  </div>
                  <div className="form-outline mb-2">
                    <TextField
                      id="query"
                      type="query"
                      variant="filled"
                      label="Message"
                      className={classes.form_control_lg}
                      error={Boolean(touched.query && errors.query)}
                      helperText={touched.query && errors.query}
                      name="query"
                      size="small"
                      multiline
                      rows={3}
                      onBlur={handleBlur}
                      onChange={handleChange}
                      value={values.query}
                    />
                  </div>
                  <div className="d-flex justify-content">
                    <Button
                      variant="contained"
                      color="primary"
                      type="submit"
                      className={classes.createAcc}
                      disabled={isSubmitting}
                    >
                      <span></span>Send
                    </Button>
                  </div>
                </form>
              </Grid>
            </div>
          )}
        </Formik>
      </div>
    </div>
  );
}

export default Queryform;
