import React from "react";

import {
  Button,
  Container,
  Grid,
  TextField,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
} from "@material-ui/core";
import MetaTitle from "components/helper/MetaTitle";
import LetsTalkBg from "../../../public/assets/Images/bg.jpg";
import { makeStyles } from "@material-ui/core";
import { Banner } from "./components";
const useStyles = makeStyles((theme) => ({
  root: {
    position: "relative",
  },
}));
function LetsTalk() {
  const classes = useStyles();
  return (
    <div className={classes.root}>
      <MetaTitle
        title={`Let's Talk | Beatnik - For those who love art, live art `}
        metaKeyWord="Beatnik - For those who love art, live art "
        metaDescription="Beatnik - For those who love art, live art "
      />
      <Banner />
    </div>
  );
}

export default LetsTalk;
