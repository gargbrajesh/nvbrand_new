export { default } from './AddFamilyDoctor';
