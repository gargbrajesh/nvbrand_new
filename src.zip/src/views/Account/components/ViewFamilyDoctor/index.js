export { default } from './ViewFamilyDoctor';
