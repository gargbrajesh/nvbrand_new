export { default } from './ComingSoon';
