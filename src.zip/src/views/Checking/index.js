export { default } from './MainComponent';
