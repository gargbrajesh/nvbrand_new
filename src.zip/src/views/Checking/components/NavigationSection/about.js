import React, { useState } from 'react';
//import { MenuItem, Select } from '@material-ui/core';
import styles from "../../checking.module.css";
import Facebook from '../../.../../../../../public/assets/Images/logo/facebook.svg';
import Instagram from '../../.../../../../../public/assets/Images/logo/instagram.svg';
import Youtube from '../../.../../../../../public/assets/Images/logo/youtube.svg';
import Vector from '../../.../../../../../public/assets/Images/logo/Vector.svg';
import Borwser from '../../.../../../../../public/assets/Images/logo/borwser.svg';
import LeftArrow from '../../.../../../../../public/assets/Images/logo/leftArrow.svg';
import RightArrow from '../../.../../../../../public/assets/Images/logo/RightArrow.svg';
//import { OutlinedInput } from '@material-ui/core';
import Cookies from 'js-cookie'
import { useRouter } from 'next/router';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Modal, Button } from "react-bootstrap";

function About() {

    const [name, setName] = useState('');
    const [gender, setGender] = useState('');
    const [city, setCity] = useState('');
    const [country, setCountry] = useState('');
    const [textarea, setTextarea] = useState('');
    const [artForm, setArtForms] = useState('');
    const [persona, setPersona] = useState('');
    const [specilization, setSpecilization] = useState('');
    const [age, setAge] = useState('');
    const [engagementType, setEngagementType] = useState('');
    const [tags, setTags] = useState('');
    const [language, setLanguage] = useState('');
    const [otheArtForm, setOtheArtForms] = useState('');
    const [message, setMessage] = useState('');
    const [selectedFile, setSelectedFile] = useState('');
    const [profile, setProfile] = useState('');
    const [isFilePicked, setIsFilePicked] = useState(false);

    var myHeaders = new Headers();
    myHeaders.append(
        'Cookie',
        'ci_session=49fe10b4cceee7e74b43eb3c532e8afda6658230',
    );

    const toBase64 = file => new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result);
        reader.onerror = error => reject(error);
    });


    const changeHandler = async (event) => {

        const base64File = await toBase64(event.target.files[0]);
        console.log(base64File);
        setProfile(base64File);
        setIsFilePicked(true);
    };

    const handleSubmission = () => {
        console.log(profile);
        handleClose();
    };
    const userID = Cookies.get('userID');
    const DataPost = () => {
        var formdata = new FormData();
        formdata.append('userID', userID);
        formdata.append('name', name);
        formdata.append('gender', gender);
        formdata.append('city', city);
        formdata.append('country', country);
        formdata.append('bio', textarea);
        formdata.append('art_form', artForm);
        formdata.append('persona', persona);
        formdata.append('specialization', specilization);

        formdata.append('profile_media_one', profile);
        formdata.append('profile_media_two', 'base 64');
        formdata.append('profile_media_three', 'base 64');
        formdata.append('profile_media_one_type', 'audio');
        formdata.append('profile_media_two_type', 'video');
        formdata.append('profile_media_three_type', 'image');

        formdata.append('age', age);
        formdata.append('engagement_type', engagementType);
        formdata.append('tags', tags);
        formdata.append('language', language);
        formdata.append('other_art_form', otheArtForm);
        formdata.append('add_flag', 'save');
        formdata.append('action', 'basic_information');

        fetch('https://app.whyuru.com/api/beatnik_portfolio_artist_add_edit', {
            method: 'POST',
            headers: myHeaders,
            body: formdata,
            redirect: 'follow',
        })
            .then((response) => response.json())
            .then((responseJson) => {
                //Hide Loader

                console.log(responseJson.valid);
                if (responseJson.valid == false) {
                    alert(responseJson.result.message);
                } else {
                    alert(responseJson.result.message);
                    console.log(responseJson);
                    alert(JSON.stringify(responseJson.result.data));
                }

            })
            .catch((error) => {

                console.log(error);
            });
            

    }
    
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);

    const ArtistEdit = async e => {
     console.log(name);
        if(name == ""){
            console.log('artist clicked');
            alert("Name can't be empty");
            return;
        }
        
        else if (gender == "") {
            alert("gender can't be empty")
        }
        else if (city == "") {
            alert("city can't be empty")
        }
        else if (country == "") {
            alert("country can't be empty")
        }
        else if (artForm == "") {
            alert("artForm can't be empty")
        }
        else if (textarea == "") {
            alert("textarea can't be empty")
        }
        else if (persona == "") {
            alert("persona can't be empty")
        }
        else if (specilization == "") {
            alert("specilization can't be empty")
        }

        else if (age == "") {
            alert("age can't be empty")
        }
        else if (engagementType == "") {
            alert("engagementType can't be empty")
        }
        else if (tags == "") {
            alert("tags can't be empty")
        }
        else if (language == "") {
            alert("language can't be empty")
        }
       
        else {
            DataPost();
        }
    };

    return (
        <>
        <div className={styles.text1}>

        <ul className={styles.ul}>
            <ul style={{ float: 'right' }}>
                <li className={styles.li}><a href="#" className={styles.a}>Save Draft</a></li>
                <li className={styles.li}><a href="/view" className={styles.a}>Preview</a></li>
                <li className={styles.li}><a href="#"  onClick={() => DataPost()} className={styles.a}>Submit</a></li>
            </ul>
        </ul>

    </div>
            <Modal show={show} onHide={handleClose}>
                <Modal.Header closeButton>
                    <Modal.Title>Modal heading</Modal.Title>
                </Modal.Header>
                <Modal.Body> <div>

                    <input type="file" name="file" onChange={changeHandler} />

                </div></Modal.Body>
                <Modal.Footer>
                    <Button variant="secondary" onClick={handleClose}>
                        Close
                    </Button>
                    <Button variant="primary" onClick={handleSubmission}>
                        Submit
                    </Button>
                </Modal.Footer>
            </Modal>

            <div className="container p-2 bg-white overflow-auto" style={{
                width: '80%',
                height: '84vh', position: "fixed", marginLeft: '2%',
                marginTop: '-10px'
            }}>
                    <p style={{ color: '#6B705A', marginLeft: '250px', fontFamily: 'Garamond', fontWeight: 700, fontSize: '42px' }}>BASIC INFORMATION</p>
                    <div className={styles.ac_input_item}>
                        <h2 style={{ color: '#FAA61A', fontFamily: 'Garamond' }}>About Us (Mandatory)</h2>
                    </div>
                    <div className={styles.ac_input_group}>
                        <div className={styles.ac_input_item}>
                            <input type='text' name='name' onChange={e => setName(e.target.value)} className="form-control p-2 px-3"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Enter your Name" autocomplete="off">

                            </input>
                        </div>

                        <div className={styles.ac_input_item}>
                            <select onChange={e => setGender(e.target.value)} name='gender' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Select Gender" autocomplete="off">
                                <option selected>Gender</option>
                                <option>Male</option>
                                <option>Female</option>
                                <option>Other</option>
                            </select>

                        </div>
                    </div>

                    <div className={styles.ac_input_group}>
                        <div className={styles.ac_input_item}>

                            <select onChange={e => setCity(e.target.value)} name='city' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Choose City" autocomplete="off">
                                <option selected>City</option>
                                <option>City1</option>
                                <option>City2</option>
                                <option>City3</option>
                                <option>City4</option>
                            </select>


                        </div>

                        <div className={styles.ac_input_item}>

                            <select onChange={e => setCountry(e.target.value)} value={country}
                                name='country' className="form-control p-2 px-1 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px', color: 'black'
                                }}
                                placeholder="Choose Country" autocomplete="off">
                                <option selected>Country</option>
                                <option>Country1</option>
                                <option>Country2</option>
                                <option>Country3</option>
                                <option>Country5</option>
                            </select>
                        </div>
                    </div>

                    <div className={styles.ac_input_group} style={{ width: '100%' }}>
                        <div className={styles.ac_input_item} style={{ width: '91%' }}>
                            <textarea className="form-control px-2" onChange={e => setTextarea(e.target.value)}
                                value={textarea}
                                name='textarea'
                                placeholder="Bio descriptions.."
                                id="exampleFormControlTextarea1" rows="5">
                            </textarea>
                        </div>
                    </div>

                    <div className={styles.ac_input_item}>
                        <h2 style={{ color: '#FAA61A', fontFamily: 'Garamond' }}>About My Art Form  (Mandatory)</h2>
                    </div>
                    <div className={styles.ac_input_group}>
                        <div className={styles.ac_input_item}>

                            <select onChange={e => setArtForms(e.target.value)} value={country}
                                name='artForm' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Choose Art Form" autocomplete="off">
                                <option value='art1'>Art Form1</option>
                                <option value='art2'>Art Form2</option>
                                <option value='art3'>Art Form3</option>
                                <option value='art4'>Art Form4</option>
                                <option value='art5'>Art Form5</option>
                            </select>

                        </div>

                        <div className={styles.ac_input_item}>

                            <select onChange={e => setPersona(e.target.value)} value={country}
                                name='country' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Choose Persona" autocomplete="off">
                                <option>Persona1</option>
                                <option>Persona2</option>
                                <option>Persona3</option>
                                <option>Persona4</option>
                                <option>Persona5</option>
                            </select>
                        </div>
                    </div>

                    <div className={styles.ac_input_group}>

                        <div className={styles.ac_input_item}>

                            <select onChange={e => setSpecilization(e.target.value)} value={country}
                                name='specilization' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Choose Specilization" autocomplete="off">
                                <option>Specilization1</option>
                                <option>Specilization2</option>
                                <option>Specilization3</option>
                                <option>Specilization4</option>
                                <option>Specilization5</option>
                            </select>
                        </div>
                    </div>
                    <div className={styles.ac_input_item}>
                        <h2 style={{ color: '#FAA61A', fontFamily: 'Garamond' }}>Profile (Mandatory)</h2>
                    </div>
                    <div className={styles.containerdiv} style={{ width: '91%' }}>
                        <button onClick={handleShow} className={styles.box} style={{ width: '17rem', textAlign: 'center', color: 'grey', paddingTop: '16px', cursor: 'pointer' }}><span style={{ fontSize: '40px' }}>+</span><br /><span className={styles.spanDesin}>upload file</span>upload media/photo/video/Audio</button>
                        <button onClick={handleShow} className={styles.box} style={{ width: '17rem', textAlign: 'center', color: 'grey', paddingTop: '16px', cursor: 'pointer' }}><span style={{ fontSize: '40px' }}>+</span><br /><span className={styles.spanDesin}>upload file</span>upload media/photo/video/Audio</button>
                        <button onClick={handleShow} className={styles.box} style={{ width: '17rem', textAlign: 'center', color: 'grey', paddingTop: '16px', cursor: 'pointer' }}><span style={{ fontSize: '40px' }}>+</span><br /><span className={styles.spanDesin}>upload file</span>upload media/photo/video/Audio</button>

                    </div>
                    <div className={styles.ac_input_item}>
                        <h2 style={{ color: '#FAA61A', fontFamily: 'Garamond' }}>Other Basic Information (NON Mandatory)</h2>
                    </div>
                    <div className={styles.ac_input_group}>
                        <div className={styles.ac_input_item}>

                            <input type='text' onChange={e => setAge(e.target.value)} className="form-control p-2 px-2"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                name='age'
                                placeholder="Enter your Age" autocomplete="off">

                            </input>
                        </div>

                        <div className={styles.ac_input_item}>

                            <select onChange={e => setEngagementType(e.target.value)} value={country}
                                name='engagementType' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Engagement Type" autocomplete="off">
                                <option>Engagement Type1</option>
                                <option>Engagement Type2</option>
                                <option>Engagement Type3</option>
                                <option>Engagement Type4</option>
                                <option>Engagement Type5</option>
                            </select>
                        </div>
                    </div>

                    <div className={styles.ac_input_group}>
                        <div className={styles.ac_input_item}>

                            <select onChange={e => setTags(e.target.value)} value={tags}
                                name='Tages' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Choose Tags" autocomplete="off">
                                <option>Tags1</option>
                                <option>Tags2</option>
                                <option>Tags3</option>
                                <option>Tags4</option>
                                <option>Tags5</option>
                            </select>
                        </div>

                        <div className={styles.ac_input_item}>



                            <select onChange={e => setLanguage(e.target.value)} value={language}
                                name='language' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Choose Language" autocomplete="off">
                                <option>Language1</option>
                                <option>Language2</option>
                                <option>Language3</option>
                                <option>Language4</option>
                                <option>Language5</option>
                            </select>
                        </div>

                    </div>


                    <div className={styles.ac_input_group}>
                        <div className={styles.ac_input_item}>

                            <select ononChange={e => setOtheArtForms(e.target.value)} value={country}
                                name='country' className="form-control p-2 px-2 form-select dropdown-toggle and the data-toggle dropdown"
                                style={{
                                    width: '27rem',
                                    borderRadius: '4px'
                                    , color: 'black'
                                }}
                                placeholder="Other Art Form" autocomplete="off">
                                <option>Other Art Form1</option>
                                <option>Other Art Form2</option>
                                <option>Other Art Form3</option>
                                <option>Other Art Form4</option>
                                <option>Other Art Form5</option>
                            </select>
                        </div>

                    </div>
                    <div className={styles.social_media}>
                        <div className={styles.grid_container}>
                            <div className={styles.grid_item}><img src={Facebook} /></div>
                            <div className={styles.grid_item}><img src={Instagram} /></div>
                            <div className={styles.grid_item}><img src={Youtube} /></div>
                            <div className={styles.grid_item}><img src={Vector} /></div>
                            <div className={styles.grid_item}><img src={Borwser} /></div>
                            <div className={styles.grid_item}>Add</div>
                            <div className={styles.grid_item}>Add</div>
                            <div className={styles.grid_item}>Add</div>
                            <div className={styles.grid_item}>Add</div>
                            <div className={styles.grid_item}>Add</div>
                        </div>

                    </div>
                    <div className={styles.container}>
                        <div className={styles.container_map}>
                            <img src={LeftArrow} style={{ marginTop: '8px', marginLeft: '5px' }} />
                        </div>
                        <div className={styles.container_buttons}>
                            <img src={RightArrow} style={{ marginTop: '8px', marginLeft: '5px' }} onClick={() => ArtistEdit()} />
                        </div>
                    </div>
                </div>
            
        </>
    )
}

export default About
