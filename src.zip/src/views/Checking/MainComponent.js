import React from 'react';
import styles from "./checking.module.css";
import { useRouter } from 'next/router';
import Training from './components/NavigationSection/training'
import Awards from './components/NavigationSection/awards'
import About from './components/NavigationSection/about'
import ArtWork from './components/NavigationSection/artwork'
import Gallary from './components/NavigationSection/galllary'
import { makeStyles, useTheme } from '@material-ui/core/styles';
import BackArrow from '../../../public/assets/Images/logo/Color.svg';
import BackButton from '../../../public/assets/Images/logo/Back.svg'
import Taining from './components/NavigationSection/training';

const useStyles = makeStyles(theme => ({
    dashboard_parent: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        width: '100vw',
        border: '2px solid black',
        height: '905px'
    },

    dashboard_right_side: {
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '100vh',
        width: '80%'

    }
}));


const MainComponent = () => {
    const classes = useStyles();
    const [activeSection, setActiveSection] = React.useState("about");

    const handleSection = (e, text) => {
        document.querySelectorAll(".dashboard_left_side_item").forEach(element => {
            element.classList.remove("dashboard_left_side_item_active")
        });
        setActiveSection(text)
        e.currentTarget.classList.add("dashboard_left_side_item_active")
    }
    return (
        <>

            <div className={styles.text}>

                <ul className={styles.ul}>
                    <li className={styles.li1}><a href="/dashboard" className={styles.a1}><img src={BackArrow}></img> <img src={BackButton}></img></a></li>
                </ul>

            </div>

            <div className={styles.container}>
                <div className={styles.container_child1}>
                    <h3 style={{ color: '#000>', marginTop: '5px' }} className="dashboard_left_side_item dashboard_left_side_item_active" onClick={(e) => { handleSection(e, "about") }} ><a href='#' className={styles.a}>BASIC INFORMATION</a></h3>
                    <h3 style={{ color: '#000>', marginTop: '10px' }} className="dashboard_left_side_item" onClick={(e) => { handleSection(e, "feature") }}><a href='#' className={styles.a}>ART WORK EXPERIENCE</a></h3>
                    <h3 style={{ color: '#000>', marginTop: '10px' }} className="dashboard_left_side_item" onClick={(e) => { handleSection(e, "training") }}><a href='#' className={styles.a}>TRAINING</a></h3>
                    <h3 style={{ color: '#000>', marginTop: '10px' }} className="dashboard_left_side_item" onClick={(e) => { handleSection(e, "award") }}><a href='#' className={styles.a}>AWARD</a></h3>
                    <h3 style={{ color: '#000>', marginTop: '10px' }} className="dashboard_left_side_item" onClick={(e) => { handleSection(e, "gallary") }}><a href='#' className={styles.a}>GALLARY</a></h3>
                </div>
                <div className={styles.container_child2}>
               

                    {
                        activeSection === "about" &&
                        <About />
                    }
                    {
                        activeSection === "feature" &&
                        <ArtWork />
                    }
                    {
                        activeSection === "training" &&
                        <Training/>
                    }
                    {
                        activeSection === "award" &&
                       <Awards/>
                    }
                    {
                        activeSection === "gallary" &&
                        <Gallary/>
                    }
                </div>
            </div>
        </>
    )
}

export default MainComponent