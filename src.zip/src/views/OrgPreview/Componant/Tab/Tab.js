import React, { useState, useEffect } from 'react';
import { Paper, } from '@material-ui/core';
import 'bootstrap/dist/css/bootstrap.min.css';
import styles from './tab.module.css';
import Cookies from 'js-cookie'
import * as Scroll from 'react-scroll';
import clsx from "clsx";
import {
    Container,
  } from "@material-ui/core";
import { Link } from 'react-scroll';
function Tab() {
    return (
        <section className={clsx(styles.Tab_cover , "mx-3")} >
        <Container spacing={2} maxWidth="xl">
            <div className={styles.center}>
            <ul className={clsx(styles.ul,'mx-5')}>
                    <li className={styles.list}><Link to="Features" spy={true} smooth={true}  duration={700} className={styles.anchor}>Features</Link></li>
                    <li className={styles.list}><Link to="Activities" spy={true} smooth={true}  duration={500} className={styles.anchor}>Activities</Link></li>
                    <li className={styles.list}><Link to="Awards" spy={true} smooth={true}  duration={500} className={styles.anchor}>Awards</Link></li>
                    <li className={styles.list}><Link to="Gallery" spy={true} smooth={true}  duration={500} className={styles.anchor}>Gallery</Link></li>
                    <li className={styles.list}><Link to="Bio" spy={true} smooth={true}  duration={500} className={styles.anchor}>Bio</Link></li>
                </ul>
                <hr />
            </div>
            </Container>
        </section>
    )
}

export default Tab


{/*  <div className={styles.arrow}>
                        <div className={styles.line}></div>
                        <div className={styles.point}></div>
                    </div>*/}