

import Girl_dance from '../../../../../public/assets/Images/logo/newgirldance.svg';

export const photos = [
    {
      src: `${Girl_dance}`,
      width: 5,
      height: 4,
    },
    {
      src:  `${Girl_dance}`,
      width: 5,
      height: 4,
    },
    {
      src:`${Girl_dance}`,
      width: 5,
      height: 4,
    },
    {
      src: `${Girl_dance}`,
      width: 5,
      height: 4,
    },
    {
      src:`${Girl_dance}`,
      width: 5,
      height: 4,
    },
    {
      src:`${Girl_dance}`,
      width: 5,
      height: 4,
    },
    {
      src:`${Girl_dance}`,
      width: 5,
      height: 4,
    },
    {
      src: `${Girl_dance}`,
      width: 5,
      height: 4,
    },
    {
      src:`${Girl_dance}`,
      width: 5,
      height: 4,
    }
  ];
  