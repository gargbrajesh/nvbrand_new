export { default } from './IconAlternate';
