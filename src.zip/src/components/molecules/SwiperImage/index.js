export { default } from './SwiperImage';
