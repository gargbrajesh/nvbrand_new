export { default } from './DescriptionCta';
