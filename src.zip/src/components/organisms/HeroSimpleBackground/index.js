export { default } from './HeroSimpleBackground';
