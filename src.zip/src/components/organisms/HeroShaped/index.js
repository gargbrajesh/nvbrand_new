export { default } from './HeroShaped';
