export { default } from './LoginCoverDesign';
