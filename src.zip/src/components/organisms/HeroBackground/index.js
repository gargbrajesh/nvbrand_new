export { default } from './HeroBackground';
