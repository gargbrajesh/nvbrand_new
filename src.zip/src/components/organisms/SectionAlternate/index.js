export { default } from './SectionAlternate';
