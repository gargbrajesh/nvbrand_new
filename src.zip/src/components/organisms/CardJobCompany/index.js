export { default } from './CardJobCompany';
