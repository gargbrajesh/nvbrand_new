export { default } from './CardJobTag';
