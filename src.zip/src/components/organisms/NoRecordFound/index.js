export { default } from './NoRecordFound';
