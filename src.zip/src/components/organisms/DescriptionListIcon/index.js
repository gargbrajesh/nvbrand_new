export { default } from './DescriptionListIcon';
