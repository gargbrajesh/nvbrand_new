export { default } from './CardJobMinimal';
