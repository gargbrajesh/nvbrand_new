export { default } from './HeroSideImage';
