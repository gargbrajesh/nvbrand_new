export { default } from './CardPromo';
