export { default } from './dashboard';
